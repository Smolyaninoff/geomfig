#ifndef FRAME_RECTANGLE_H
#define FRAME_RECTANGLE_H

#include "Point.h"

struct FrameRectangle {
    float width_;
    float height_;
    Point pos_;

};

#endif
